package com.karrotking.alarmtest;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;


public class AlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "alarm_test_channel";
    private static final int NOTIFICATION_ID = 9001;

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Alarm Test",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Single-shot native alarm test");
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 700, 300, 700, 300, 1200});
        channel.setSound(sound, audioAttributes);

        nm.createNotificationChannel(channel);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        createChannel(context);

        // Wake the CPU briefly while the notification is posted.
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = null;
        if (pm != null) {
            wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "AlarmTest:ReceiverWakeLock"
            );
            wakeLock.acquire(10_000L);
        }

        Intent openIntent = new Intent(context, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                9002,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        android.app.Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new android.app.Notification.Builder(context, CHANNEL_ID);
        } else {
            builder = new android.app.Notification.Builder(context);
            builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        }

        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("🚨 ALARM TEST")
                .setContentText("30 seconds completed — the native alarm fired.")
                .setStyle(new android.app.Notification.BigTextStyle()
                        .bigText("30 seconds completed.\n\nIf the screen was locked, this proves the native Android alarm reached the receiver."))
                .setPriority(android.app.Notification.PRIORITY_MAX)
                .setCategory(android.app.Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setOngoing(false)
                .setContentIntent(contentIntent)
                .setVibrate(new long[]{0, 700, 300, 700, 300, 1200})
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, builder.build());

        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }
}
