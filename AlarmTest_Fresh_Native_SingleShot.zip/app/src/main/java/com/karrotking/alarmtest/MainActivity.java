package com.karrotking.alarmtest;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_NOTIFICATIONS = 1001;
    private static final int REQUEST_CODE = 4242;

    private TextView statusText;
    private AlarmManager alarmManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button startButton = findViewById(R.id.startButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        Button permissionButton = findViewById(R.id.permissionButton);

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        createNotificationChannel();
        requestNotificationPermissionIfNeeded();

        startButton.setOnClickListener(v -> scheduleAlarm());
        cancelButton.setOnClickListener(v -> cancelAlarm());
        permissionButton.setOnClickListener(v -> openExactAlarmSettings());

        updatePermissionStatus();
    }

    private void scheduleAlarm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && !alarmManager.canScheduleExactAlarms()) {
            statusText.setText("EXACT ALARM ACCESS IS NOT GRANTED. Tap CHECK / ALLOW EXACT ALARMS first.");
            openExactAlarmSettings();
            return;
        }

        long triggerAt = System.currentTimeMillis() + 30_000L;

        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                pendingIntent
        );

        statusText.setText("SINGLE-SHOT ALARM SCHEDULED.\n\nLock the phone now.\nIt should fire in 30 seconds.");
    }

    private void cancelAlarm() {
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        alarmManager.cancel(pendingIntent);
        statusText.setText("Alarm cancelled.");
    }

    private void updatePermissionStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            boolean allowed = alarmManager.canScheduleExactAlarms();
            statusText.setText(allowed
                    ? "Exact alarms: ALLOWED\nReady for the 30-second single-shot test."
                    : "Exact alarms: NOT ALLOWED\nTap CHECK / ALLOW EXACT ALARMS.");
        } else {
            statusText.setText("Exact-alarm permission is not required on this Android version.");
        }
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQUEST_NOTIFICATIONS
            );
        }
    }

    private void createNotificationChannel() {
        AlarmReceiver.createChannel(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (statusText != null && alarmManager != null) {
            updatePermissionStatus();
        }
    }
}
