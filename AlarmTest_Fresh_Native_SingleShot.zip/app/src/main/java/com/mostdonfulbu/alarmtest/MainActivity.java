package com.mostdonfulbu.alarmtest;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    static final int REQ_NOTIF = 100;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,60,40,40);
        TextView title=new TextView(this); title.setText("AlarmTest Fresh — Native only"); title.setTextSize(24); title.setTextColor(Color.DKGRAY);
        TextView info=new TextView(this); info.setText("No WebView. No JavaScript. No wake lock.\nUses AlarmManager.setExactAndAllowWhileIdle()."); info.setTextSize(17); info.setPadding(0,30,0,30);
        Button button=new Button(this); button.setText("SET 2-MINUTE NATIVE ALARM");
        TextView status=new TextView(this); status.setTextSize(16); status.setPadding(0,30,0,0);
        box.addView(title); box.addView(info); box.addView(button); box.addView(status); setContentView(box);
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},REQ_NOTIF);
        button.setOnClickListener(v -> schedule(status));
    }
    void schedule(TextView status) {
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
            try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); } catch(Exception ignored) {}
            status.setText("Allow exact alarms, then press the button again."); return;
        }
        long when=System.currentTimeMillis()+120000L;
        Intent i=new Intent(this,AlarmReceiver.class).putExtra("when",when);
        PendingIntent pi=PendingIntent.getBroadcast(this,7,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        status.setText("Native alarm scheduled for: "+android.text.format.DateFormat.format("HH:mm:ss",when));
        Toast.makeText(this,"Alarm scheduled — now background and lock the phone",Toast.LENGTH_LONG).show();
    }
}
