package com.mostdonfulbu.alarmtest;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;


public class AlarmReceiver extends BroadcastReceiver {
    static final String CHANNEL="native_alarm_test";
    @Override public void onReceive(Context c, Intent i) {
        long fired=System.currentTimeMillis();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Native Alarm Test",NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true); ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()); nm.createNotificationChannel(ch);
        }
        Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("ALARMTEST — NATIVE ALARM FIRED").setContentText("Receiver fired at "+android.text.format.DateFormat.format("HH:mm:ss",fired)+" — no JavaScript involved.").setCategory(Notification.CATEGORY_ALARM).setAutoCancel(true).setVibrate(new long[]{0,500,250,500,250,500}).build();
        nm.notify(7007,n);
    }
}
