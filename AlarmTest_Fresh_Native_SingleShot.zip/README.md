# Fresh Native Alarm Test

This is deliberately NOT Karrot King.

It is a clean, single-shot Android alarm test designed to answer one question:

> Can this phone deliver an exact native Android alarm while the screen is locked?

## Test

1. Build/install the debug APK.
2. Open **Alarm Test**.
3. Allow notifications if Android asks.
4. Tap **CHECK / ALLOW EXACT ALARMS** if exact alarms are not allowed.
5. Return to the app and confirm it says **Exact alarms: ALLOWED**.
6. Tap **START 30-SECOND ALARM**.
7. Immediately lock the phone.
8. Wait at least 45 seconds.

Expected result:
- Alarm notification appears.
- Alarm sound plays.
- Vibration occurs.
- The notification says **ALARM TEST**.

## Important

This is intentionally:
- one alarm
- no repeating alarm
- no WebView
- no JavaScript timer
- no irrigation logic
- no foreground service
- no looping vibration

If this test fails with the screen locked, do not modify the test app yet. The result tells us the problem is below the Karrot King irrigation layer.
