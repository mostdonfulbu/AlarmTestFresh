# Fresh Native Single-Shot Alarm Test v1.1

A deliberately minimal native Android alarm test.

This v1.1 build removes AndroidX completely. The previous GitHub build failed before producing an APK because of an unrelated Kotlin stdlib duplicate-class dependency conflict.

The alarm mechanism itself remains:
- one single-shot alarm
- AlarmManager
- RTC_WAKEUP
- setExactAndAllowWhileIdle()
- BroadcastReceiver
- high-priority notification
- alarm sound
- vibration
- no WebView
- no JavaScript
- no repeating alarm
- no foreground service

Test:
1. Build/install the APK.
2. Allow notifications.
3. Ensure Exact alarms says ALLOWED in the app.
4. Tap START 30-SECOND ALARM.
5. Immediately lock the phone.
6. Wait at least 45 seconds.

Expected: the native alarm notification appears with sound and vibration.
